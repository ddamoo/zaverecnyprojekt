# Analýza letových statusov – ELT projekt

## Úvod a popis zdrojových dát

Tento projekt sa zameriava na **analýzu letových statusov** na základe dát zo **Snowflake Marketplace**. Cieľom je vytvoriť **stabilný ELT proces**, ktorý umožní spracovanie, čistenie a vizualizáciu dát o letoch a leteckých spoločnostiach.

### Prečo bol dataset vybraný
Dataset obsahuje informácie o aktuálnych a historických letových statusoch, čo umožňuje analyzovať výkonnosť leteckých dopravcov, identifikovať časté meškania a podporiť rozhodovanie v leteckom biznise.  

### Biznis proces podporovaný dátami
- Monitorovanie letov a ich stavov (On Time, Delayed, Cancelled)  
- Analýza efektivity leteckých spoločností  
- Podpora reportingu a rozhodovania v prevádzke letísk alebo leteckých spoločností  

### Typy údajov
- **Identifikátory letov a dopravcov:** IATA/ICAO kódy, číslo letu  
- **Dátumy a časové údaje:** dátum plánovaného odletu  
- **Statusy letov:** On Time, Delayed, Cancelled  
- **Typy letov:** pravidelné alebo charterové  

### Cieľ analýzy
- Čistenie a deduplikácia dát  
- Tvorba dimenzií a faktovej tabuľky (Star Schema)  
- Analýza počtu letov, statusov, ranking dopravcov pomocou **window funkcií**  
- Vizualizácia kľúčových metrík a trendov v letovej doprave  

### Popis jednotlivých tabuliek

|       Tabuľka         |                               Popis                                     |                Význam v doméne                                    |

| `stg_flight_status`   | Staging tabuľka s nevyčistenými dátami zo Snowflake Marketplace         | Slúži ako surový zdroj dát pre ELT proces                         |
| `clean_flight_status` | Čistená a deduplikovaná verzia stg tabulky                              | Odstránenie NULL hodnôt, deduplikácia, správne dátové typy        |
| `dim_carrier`         | Dimenzia leteckých spoločností (IATA, ICAO kódy, platnosť)              | Umožňuje analýzu a spájanie dát podľa dopravcov                   |
| `dim_flight`          | Dimenzia letov (číslo letu, typ letu)                                   | Kategorizácia letov, prepojenie na faktovú tabuľku                |
| `dim_status`          | Dimenzia statusov letov                                                 | Slúži na klasifikáciu a filtrovanie letov podľa stavu             |
| `dim_date`            | Dimenzia dátumov (rok, mesiac, deň)                                     | Pre podporu časových analýz a agregácií                           |
| `fact_flight_status`  | Faktová tabuľka obsahujúca všetky letové záznamy, počty letov a ranking | Umožňuje analytiku, vizualizácie a reporting výkonnosti dopravcov |

Meno a priezvisko:
Damian Bartek