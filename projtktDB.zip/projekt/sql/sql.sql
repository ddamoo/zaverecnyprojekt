pocet letov podla dopravcu
sELECT 
    c.IATA_CARRIER_CODE,
    COUNT(*) AS flights_count
FROM BOA_DB.FACT.fact_flight_status fs
JOIN BOA_DB.DIM.dim_carrier c
    ON fs.IATA_CARRIER_CODE = c.IATA_CARRIER_CODE
GROUP BY c.IATA_CARRIER_CODE
ORDER BY flights_count DESC;


najcastejsi stav letu
SELECT 
    s.STATUS_KEY,
    COUNT(*) AS status_count
FROM BOA_DB.FACT.fact_flight_status fs
JOIN BOA_DB.DIM.dim_status s
    ON fs.STATUS_KEY = s.STATUS_KEY
GROUP BY s.STATUS_KEY
ORDER BY status_count DESC;


kumulativny pocet letov podla dopravcu
SELECT 
    fs.IATA_CARRIER_CODE,
    fs.FLIGHT_DATE,
    SUM(1) OVER (
        PARTITION BY fs.IATA_CARRIER_CODE
        ORDER BY fs.FLIGHT_DATE
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS cumulative_flights
FROM BOA_DB.FACT.fact_flight_status fs
ORDER BY fs.IATA_CARRIER_CODE, fs.FLIGHT_DATE;


vyvoj poctu letov v case
SELECT 
    d.FLIGHT_DATE,
    COUNT(*) AS flights_per_day
FROM BOA_DB.FACT.fact_flight_status fs
JOIN BOA_DB.DIM.dim_date d
    ON fs.FLIGHT_DATE = d.FLIGHT_DATE
GROUP BY d.FLIGHT_DATE
ORDER BY d.FLIGHT_DATE;


denne poradie dopravcov podla poctu letov

SELECT 
    FLIGHT_DATE,
    IATA_CARRIER_CODE,
    daily_carrier_rank
FROM BOA_DB.FACT.fact_flight_status
ORDER BY FLIGHT_DATE, daily_carrier_rank;
